import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from equating import perform_multi_session_equating, run_cached_session_irt
from excel_exporter import convert_df_to_csv_bytes, create_excel_report
from irt_analysis import run_irt_analysis
from scoring import calculate_person_fit
from ui_components import render_irt_icc, render_irt_tif, render_wright_map


def render_tab_irt(df_matrix, dfs, ctt_res):
    st.subheader("Analisis Item Response Theory (IRT)")

    if df_matrix is None or df_matrix.empty:
        st.warning("⚠️ Data matriks belum siap untuk dianalisis IRT.")
        return

    if "irt_results" not in st.session_state or not isinstance(st.session_state["irt_results"], dict):
        st.session_state["irt_results"] = {}

    col_m1, col_m2, col_m3 = st.columns([2, 1, 1])

    with col_m1:
        selected_model = st.radio(
            "Pilih Model IRT:",
            options=["Rasch", "1PL", "2PL", "3PL"],
            key="selected_model_irt_radio",
            horizontal=True,
        )

    with col_m2:
        scale_min = st.number_input(
            "Skala Nilai Min:", value=200, step=50, key="scale_min_input"
        )

    with col_m3:
        scale_max = st.number_input(
            "Skala Nilai Max:", value=800, step=50, key="scale_max_input"
        )

    model_key = "rasch" if selected_model.lower() in ["rasch", "1pl"] else selected_model.lower()

    # Ambil hasil pre-computation atau jalankan jika belum ada
    if model_key in st.session_state["irt_results"] and st.session_state["irt_results"][model_key].get("df_person") is not None:
        cache_data = st.session_state["irt_results"][model_key]
        df_persons_raw = cache_data["df_person"].copy()
        df_params = cache_data["item_params"].copy()
        irt_res = {"person_params": df_persons_raw, "item_params": df_params}
    else:
        try:
            with st.spinner(f"⏳ Menghitung Estimasi Model IRT ({selected_model})..."):
                irt_res = run_irt_analysis(df_matrix, model_type=selected_model)
                st.session_state["irt_results"][model_key] = {
                    "df_person": irt_res.get("person_params"),
                    "item_params": irt_res.get("item_params"),
                }
        except Exception as e:
            st.error(f"❌ Terjadi kesalahan saat menghitung Model IRT ({selected_model}): {e}")
            return

    if not irt_res:
        st.error("⚠️ Hasil analisis IRT bernilai kosong.")
        return

    # --- PENYETARAAN MULTI-SESI ---
    df_respon_raw = dfs.get("respon", pd.DataFrame()) if isinstance(dfs, dict) else pd.DataFrame()
    
    col_sesi_candidate = None
    if not df_respon_raw.empty:
        col_sesi_candidate = next(
            (
                c
                for c in df_respon_raw.columns
                if c.lower().strip()
                in ["kode_sesi", "kodesesi", "sesi", "session_id", "session"]
            ),
            None,
        )

    equating_meta = {"is_multi_session": False}

    if col_sesi_candidate:
        unique_sessions = sorted(df_respon_raw[col_sesi_candidate].dropna().unique())
        if len(unique_sessions) > 1:
            st.markdown("---")
            st.markdown("### 🔄 Penyetaraan Multi-Sesi (Multi-Session Equating)")

            base_sess = st.selectbox(
                "Pilih Sesi Acuan (Base Session):",
                options=unique_sessions,
                index=0,
                help="Sesi acuan dijadikan standar skala. Sesi lainnya akan diselaraskan ke skala sesi acuan ini.",
            )

            user_id_col = next(
                (
                    c
                    for c in df_respon_raw.columns
                    if c.lower().strip() in ["username", "user_id", "id_peserta"]
                ),
                df_respon_raw.columns[0],
            )

            session_irt_results = {}
            for sess in unique_sessions:
                users_in_sess = (
                    df_respon_raw[df_respon_raw[col_sesi_candidate] == sess][
                        user_id_col
                    ]
                    .astype(str)
                    .str.strip()
                    .str.lower()
                    .tolist()
                )
                id_col_m = df_matrix.columns[0]
                df_sub_matrix = df_matrix[
                    df_matrix[id_col_m]
                    .astype(str)
                    .str.strip()
                    .str.lower()
                    .isin(users_in_sess)
                ].copy()

                if not df_sub_matrix.empty:
                    session_irt_results[sess] = run_cached_session_irt(
                        df_sub_matrix, model_type=selected_model
                    )

            equated_results, equating_meta = perform_multi_session_equating(
                df_responses=df_respon_raw,
                session_irt_results=session_irt_results,
                base_session_id=base_sess,
            )

            if equating_meta.get("is_multi_session", False):
                st.subheader("📊 Hasil Evaluasi Psikometri & Penyetaraan Multi-Sesi")

                for sess_id, report in equating_meta.get("reports", {}).items():
                    with st.expander(
                        f"📌 Ringkasan Penyetaraan: Sesi {sess_id} ➔ Sesi {base_sess}",
                        expanded=True,
                    ):
                        if report["status"] == "SUCCESS":
                            col1, col2, col3 = st.columns(3)
                            col1.metric(
                                "Soal Jangkar",
                                f"{report['n_anchor']} Butir",
                                f"{report['anchor_ratio']:.1f}%",
                            )
                            col2.metric(
                                "Korelasi Kesukaran (r)", f"{report['correlation']:.2f}"
                            )
                            col3.metric(
                                "Konstanta (A / B)",
                                f"{report['A']:.3f} / {report['B']:.3f}",
                            )

                            st.markdown("**Catatan Evaluasi Psikometri:**")
                            for warn in report["warnings"]:
                                st.markdown(warn)
                        else:
                            st.error(report["warnings"][0])
            st.markdown("---")

    id_col = df_matrix.columns[0]
    skor_col_name = "skor_mentah"

    df_params = irt_res.get("item_params", pd.DataFrame()).copy()
    df_persons = irt_res.get("person_params", pd.DataFrame()).copy()

    if not df_params.empty:
        param_item_col = df_params.columns[0]
        df_params = df_params[
            ~df_params[param_item_col]
            .astype(str)
            .str.lower()
            .isin(["jumlah_soal", "jumlahsoal"])
        ].copy()

    theta_col = None
    if not df_persons.empty:
        for col in df_persons.columns:
            if col.lower() in [
                "kemampuan (theta θ)",
                "theta",
                "theta_ability",
                "ability",
                "skor_theta",
            ]:
                if not df_persons[col].isna().all():
                    theta_col = col
                    break
        if theta_col is None:
            numeric_cols = df_persons.select_dtypes(include=[np.number]).columns
            theta_col = (
                numeric_cols[0]
                if len(numeric_cols) > 0
                else (
                    df_persons.columns[1]
                    if len(df_persons.columns) > 1
                    else df_persons.columns[0]
                )
            )

    t_min = (
        df_persons[theta_col].min() if (theta_col and not df_persons.empty) else 0
    )
    t_max = (
        df_persons[theta_col].max() if (theta_col and not df_persons.empty) else 0
    )

    if (
        pd.notna(t_min)
        and pd.notna(t_max)
        and t_max != t_min
        and theta_col in df_persons.columns
    ):
        theta_arr = df_persons[theta_col].values
        df_persons["Nilai_Scaled"] = np.round(
            scale_min + ((theta_arr - t_min) / (t_max - t_min)) * (scale_max - scale_min),
            2,
        )
    else:
        df_persons["Nilai_Scaled"] = (scale_min + scale_max) / 2.0

    # Simpan kembali pembaruan skala ke session_state
    st.session_state["irt_results"][model_key] = {"df_person": df_persons, "item_params": df_params}

    df_persons_display = df_persons.copy()
    if not df_persons_display.empty:
        person_id_col = df_persons_display.columns[0]
        score_map = dict(
            zip(df_matrix[id_col].astype(str), df_matrix[skor_col_name])
        )
        df_persons_display["Skor Mentah"] = (
            df_persons_display[person_id_col].astype(str).map(score_map)
        )

        b_candidates = [
            c
            for c in df_params.columns
            if c.lower()
            in ["b", "kesukaran", "difficulty", "b_param", "tingkat_kesukaran (b)"]
        ]
        b_col = (
            b_candidates[0]
            if len(b_candidates) > 0
            else (
                df_params.columns[1]
                if len(df_params.columns) > 1
                else df_params.columns[0]
            )
        )

        df_fit = calculate_person_fit(df_matrix, df_params, b_col=b_col)

        df_persons_display[person_id_col] = (
            df_persons_display[person_id_col].astype(str).str.strip()
        )
        df_fit[id_col] = df_fit[id_col].astype(str).str.strip()

        df_persons_display = df_persons_display.merge(
            df_fit, left_on=person_id_col, right_on=id_col, how="left"
        )

        rename_dict = {}
        if person_id_col != "ID Peserta":
            rename_dict[person_id_col] = "ID Peserta"
        if "Nilai_Scaled" in df_persons_display.columns:
            rename_dict["Nilai_Scaled"] = "Nilai Konversi"
        if theta_col and theta_col != "Kemampuan (Theta θ)":
            rename_dict[theta_col] = "Kemampuan (Theta θ)"

        df_persons_display = df_persons_display.rename(columns=rename_dict)
        df_persons_display = df_persons_display.loc[
            :, ~df_persons_display.columns.duplicated()
        ]

        target_cols = [
            "ID Peserta",
            "Skor Mentah",
            "Kemampuan (Theta θ)",
            "Nilai Konversi",
            "Outfit_MSQ",
            "Status_Pola_Jawab",
        ]
        if "SEM" in df_persons_display.columns:
            target_cols.append("SEM")

        df_irt_final = df_persons_display[
            [c for c in target_cols if c in df_persons_display.columns]
        ].copy()
        df_irt_final = df_irt_final.loc[:, ~df_irt_final.columns.duplicated()]

        if "No." not in df_irt_final.columns:
            df_irt_final.insert(0, "No.", range(1, 1 + len(df_irt_final)))
    else:
        df_irt_final = pd.DataFrame()

    if not df_persons.empty and theta_col in df_persons.columns:
        st.markdown("#### 📊 Statistik Deskriptif Estimasi Ability (Theta θ)")

        theta_vals = pd.to_numeric(df_persons[theta_col], errors="coerce").dropna()
        scaled_vals = (
            pd.to_numeric(df_persons["Nilai_Scaled"], errors="coerce").dropna()
            if "Nilai_Scaled" in df_persons.columns
            else pd.Series()
        )

        desc_data = {
            "Metrik Statistik": [
                "Jumlah Peserta (N)",
                "Rata-rata (Mean)",
                "Standar Deviasi (SD)",
                "Nilai Minimum",
                "Kuartil 1 (Q1 - 25%)",
                "Median (Q2 - 50%)",
                "Kuartil 3 (Q3 - 75%)",
                "Nilai Maksimum",
                "Kemiringan (Skewness)",
                "Keruncingan (Kurtosis)",
            ],
            "Skala Theta (θ)": [
                f"{len(theta_vals):,}",
                f"{theta_vals.mean():.3f}",
                f"{theta_vals.std():.3f}",
                f"{theta_vals.min():.3f}",
                f"{theta_vals.quantile(0.25):.3f}",
                f"{theta_vals.median():.3f}",
                f"{theta_vals.quantile(0.75):.3f}",
                f"{theta_vals.max():.3f}",
                f"{theta_vals.skew():.3f}",
                f"{theta_vals.kurtosis():.3f}",
            ],
        }

        if not scaled_vals.empty:
            desc_data[f"Skala Konversi ({scale_min} - {scale_max})"] = [
                f"{len(scaled_vals):,}",
                f"{scaled_vals.mean():.2f}",
                f"{scaled_vals.std():.2f}",
                f"{scaled_vals.min():.2f}",
                f"{scaled_vals.quantile(0.25):.2f}",
                f"{scaled_vals.median():.2f}",
                f"{scaled_vals.quantile(0.75):.2f}",
                f"{scaled_vals.max():.2f}",
                f"{scaled_vals.skew():.3f}",
                f"{scaled_vals.kurtosis():.3f}",
            ]

        df_desc = pd.DataFrame(desc_data)
        st.dataframe(df_desc, use_container_width=True, hide_index=True)
        st.divider()

    # --- GRAFIK DISTRIBUSI ---
    if not df_persons.empty and "Nilai_Scaled" in df_persons.columns:
        st.markdown(
            f"#### 📈 Grafik Distribusi Nilai Konversi Peserta (Model: {selected_model})"
        )
        
        st.caption("🎯 **Tujuan:** Menampilkan gambaran umum sebaran skor/nilai hasil konversi seluruh peserta tes.")
        
        with st.expander("📖 Cara Membaca Grafik Distribusi Nilai Konversi"):
            st.markdown(
                """
            * **Batang Grafik (Histogram):** Menunjukkan jumlah peserta pada rentang nilai tertentu. Jika puncak grafik berada di tengah, sebaran nilai peserta tergolong normal dan seimbang.
            * **Boxplot (Garis/Kotak di Atas):** Menunjukkan nilai tengah (*median*), rentang 50% nilai peserta terbanyak (kotak utama), serta nilai tertinggi, terendah, dan pencilan (*outlier*).
            """
            )

        chart_data = (
            df_persons["Nilai_Scaled"].sample(n=30000, random_state=42)
            if len(df_persons) > 30000
            else df_persons["Nilai_Scaled"]
        ).dropna()

        fig_dist_irt = px.histogram(
            chart_data,
            x="Nilai_Scaled",
            nbins=30,
            title=f"<b>Distribusi Nilai Konversi Peserta (Skala {scale_min} - {scale_max})</b>",
            labels={"Nilai_Scaled": "Nilai Konversi", "count": "Jumlah Peserta"},
            color_discrete_sequence=["#00CC96"],
            marginal="box",
        )

        fig_dist_irt.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="<b>Nilai Konversi</b>",
            yaxis_title="<b>Jumlah Peserta</b>",
            bargap=0.08,
        )

        st.plotly_chart(fig_dist_irt, use_container_width=True)
        st.divider()

    # --- GRAFIK ICC, TIF, DAN WRIGHT MAP ---
    if not df_params.empty:
        b_candidates = [
            c
            for c in df_params.columns
            if c.lower()
            in ["b", "kesukaran", "difficulty", "b_param", "tingkat_kesukaran (b)"]
        ]
        b_col = (
            b_candidates[0]
            if len(b_candidates) > 0
            else (
                df_params.columns[1]
                if len(df_params.columns) > 1
                else df_params.columns[0]
            )
        )

        item_col_name = df_params.columns[0]
        all_items = df_params[item_col_name].astype(str).tolist()
        selected_items = st.multiselect(
            "Filter Soal untuk Menampilkan ICC:",
            options=all_items,
            default=all_items[:5] if len(all_items) >= 5 else all_items,
            key="icc_filter_soal",
        )

        st.markdown(f"#### Item Characteristic Curves (ICC) - Model {selected_model}")
        st.caption("🎯 **Tujuan:** Mengetahui tingkat kesulitan dan daya beda dari masing-masing butir soal secara individual.")
        with st.expander("📖 Cara Membaca Kurva ICC"):
            st.markdown(
                """
            * **Sumbu Horizontal (Bawah):** Kemampuan peserta ($\theta$). Semakin ke kanan, peserta semakin pandai.
            * **Sumbu Vertikal (Kiri):** Peluang menjawab benar (0,0 = 0% hingga 1,0 = 100%).
            * **Posisi Kurva Soal:**
              * Kurva di sebelah **kiri** menandakan **soal mudah**.
              * Kurva di sebelah **kanan** menandakan **soal sulit** (hanya peserta berkemampuan tinggi yang berpeluang besar menjawab benar).
            """
            )

        fig_icc = render_irt_icc(df_params, selected_items, selected_model, b_col)
        st.plotly_chart(fig_icc, use_container_width=True)

        st.divider()

        col_chart1, col_chart2 = st.columns(2)

        with col_chart1:
            st.markdown("#### Test Information Function (TIF) & SEM")
            st.caption("🎯 **Tujuan:** Mengukur sejauh mana seluruh perangkat soal dapat mengukur kemampuan peserta secara akurat.")
            with st.expander("📖 Cara Membaca Grafik TIF & SEM"):
                st.markdown(
                    """
                * **Garis Informasi / TIF (Biru):** Semakin tinggi puncaknya, semakin akurat tes tersebut mengukur peserta pada tingkat kemampuan tersebut.
                * **Garis Kesalahan / SEM (Merah):** Menunjukkan tingkat kesalahan pengukuran.
                * **Kondisi Ideal:** Pada area di mana garis TIF tinggi, garis SEM harus berada di posisi paling rendah.
                """
                )
            fig_tif = render_irt_tif(df_params, selected_model, b_col)
            st.plotly_chart(fig_tif, use_container_width=True)

        with col_chart2:
            st.markdown("#### Wright Map (Peta Peserta & Soal)")
            st.caption("🎯 **Tujuan:** Membandingkan tingkat kemampuan peserta dengan tingkat kesulitan soal pada satu skala yang sama.")
            with st.expander("📖 Cara Membaca Wright Map"):
                st.markdown(
                    """
                * **Sebaran Peserta (Kiri):** Titik/kotak menunjukkan posisi kemampuan peserta. Semakin tinggi posisinya, semakin tinggi kemampuan pesertanya.
                * **Sebaran Soal (Kanan):** Menunjukkan posisi tingkat kesulitan soal. Semakin tinggi posisinya, semakin sulit soal tersebut.
                * **Evaluasi Sebaran:** Jika sebaran peserta dan soal sejajar/berada pada rentang yang sama, artinya instrumen tes ini **sangat ideal** untuk populasi peserta tersebut.
                """
                )
            df_persons_wright = (
                df_persons.sample(n=5000, random_state=42)
                if len(df_persons) > 5000
                else df_persons
            )
            fig_wright = render_wright_map(
                df_persons_wright, df_params, theta_col, b_col
            )
            st.plotly_chart(fig_wright, use_container_width=True)

    st.divider()
    col_irt_item, col_irt_person = st.columns(2)
    with col_irt_item:
        st.write("**Parameter Soal (IRT):**")
        df_params_display = df_params.copy()
        df_params_display = df_params_display.loc[
            :, ~df_params_display.columns.duplicated()
        ]
        if "No." not in df_params_display.columns:
            df_params_display.insert(0, "No.", range(1, 1 + len(df_params_display)))
        st.dataframe(df_params_display, use_container_width=True, hide_index=True)

    with col_irt_person:
        st.write("**Estimasi Kemampuan Peserta & Person Fit (Anomali):**")
        st.dataframe(
            df_irt_final.head(100), use_container_width=True, hide_index=True
        )
        st.caption("⚡ Menampilkan 100 sampel data pertama untuk efisiensi memori UI.")

    st.divider()
    st.subheader("📥 Unduh Hasil Analisis IRT & Rekap Excel")
    col_dl1, col_dl2 = st.columns(2)

    with col_dl1:
        df_items = ctt_res.get("item_stats", pd.DataFrame()) if isinstance(ctt_res, dict) else pd.DataFrame()
        excel_data = create_excel_report(
            df_matrix=df_matrix,
            df_items=df_items,
            df_dist=ctt_res.get("distractor_stats", pd.DataFrame()) if isinstance(ctt_res, dict) else pd.DataFrame(),
            df_params=df_params,
            df_persons_irt=df_irt_final,
            equating_meta=equating_meta,
        )
        st.download_button(
            label="📊 Download Ringkasan Soal & Item (.xlsx)",
            data=excel_data,
            file_name=f"Laporan_Psikometri_Item_{selected_model}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
            key="btn_dl_excel",
        )

    with col_dl2:
        csv_data_person = convert_df_to_csv_bytes(df_irt_final)
        st.download_button(
            label="📄 Download Data Lengkap Peserta IRT (.csv)",
            data=csv_data_person,
            file_name=f"Hasil_Nilai_Peserta_Lengkap_{selected_model}.csv",
            mime="text/csv",
            type="primary",
            use_container_width=True,
            key="btn_dl_csv",
        )