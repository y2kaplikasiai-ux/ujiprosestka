import streamlit as st
from ui_components import render_score_histogram


def render_tab_scoring(df_matrix):
    st.subheader("Hasil Skoring Dikotomus (0 / 1)")
    id_col = df_matrix.columns[0]
    skor_col_name = "skor_mentah"

    c1, c2, c3 = st.columns(3)
    c1.metric("Total Responden", f"{len(df_matrix):,}")

    avg_skor = df_matrix[skor_col_name].mean()
    avg_soal = df_matrix["Jumlah_Soal"].mean()
    c2.metric("Rata-rata Skor Mentah", f"{avg_skor:.2f} / {avg_soal:.1f}")

    avg_konversi = df_matrix["Nilai_Konversi"].mean()
    c3.metric("Rata-rata Nilai Konversi", f"{avg_konversi:.2f}")
    st.divider()

    df_chart = (
        df_matrix.sample(n=50000, random_state=42)
        if len(df_matrix) > 50000
        else df_matrix
    )
    fig_score = render_score_histogram(df_chart)
    st.plotly_chart(fig_score, use_container_width=True)

    df_display_scoring = df_matrix.copy()

    selected_cols = []
    for col in [
        id_col,
        "tahun",
        "username",
        "Jumlah_Soal",
        "skor_mentah",
        "Nilai_Konversi",
    ]:
        if col in df_display_scoring.columns and col not in selected_cols:
            selected_cols.append(col)

    df_display_scoring = df_display_scoring[selected_cols].head(100).copy()

    rename_map = {
        id_col: "Username",
        "username": "Username",
        "Jumlah_Soal": "Jumlah Soal",
        "skor_mentah": "Skor Mentah",
        "Nilai_Konversi": "Nilai Konversi",
    }
    df_display_scoring.rename(columns=rename_map, inplace=True)
    df_display_scoring = df_display_scoring.loc[
        :, ~df_display_scoring.columns.duplicated()
    ].copy()

    if "No." not in df_display_scoring.columns:
        df_display_scoring.insert(0, "No.", range(1, 1 + len(df_display_scoring)))

    st.dataframe(df_display_scoring, use_container_width=True, hide_index=True)
    st.caption("⚡ Menampilkan 100 sampel data pertama untuk efisiensi memori UI.")