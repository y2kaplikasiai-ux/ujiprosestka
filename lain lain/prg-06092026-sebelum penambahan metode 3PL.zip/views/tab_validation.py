import streamlit as st


def render_tab_validation(val_result):
    st.subheader("Hasil Pemeriksaan Ingestion Data")
    for log in val_result["logs"]:
        if "❌" in log:
            st.error(log)
        elif "⚠️" in log:
            st.warning(log)
        elif "---" in log:
            st.markdown(f"**{log}**")
        else:
            st.success(log)

    if val_result["status"]:
        st.success("🎉 Data berhasil divalidasi dan siap untuk diproses!")
        st.divider()
        preview_key = st.selectbox(
            "Pilih Tabel untuk Ditinjau:", list(val_result["dataframes"].keys())
        )
        if (
            preview_key in val_result["dataframes"]
            and val_result["dataframes"][preview_key] is not None
        ):
            df_preview = val_result["dataframes"][preview_key].head(10).copy()
            df_preview = df_preview.loc[:, ~df_preview.columns.duplicated()]
            df_preview.insert(0, "No.", range(1, 1 + len(df_preview)))
            st.dataframe(df_preview, use_container_width=True, hide_index=True)