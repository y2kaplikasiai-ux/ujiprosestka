import numpy as np
import pandas as pd


def get_item_columns(df):
    """Mengekstrak kolom kode soal."""
    non_item_keywords = [
        'username',
        'tahun',
        'kode_jenjang',
        'kode_mapel',
        'kode_paket',
        'list_soal',
        'respon',
        'skor_mentah',
        'nilai_konversi',
        'no',
        'no.',
        'id',
        'nama',
        'sekolah',
        'npsn',
        'kelas',
        'unnamed',
        'jumlah_soal_dikerjakan',
        'jumlah_soal',
    ]

    item_cols = []
    for col in df.columns:
        col_str = str(col).strip().lower()
        if any(kw in col_str for kw in non_item_keywords):
            continue
        item_cols.append(col)

    return item_cols


def calculate_distractor_analysis(df_respon=None, df_kunci=None, df_matrix=None):
    """Analisis distractor/pengecoh."""
    return pd.DataFrame(
        columns=['Kode_Soal', 'Opsi', 'Jumlah_Pemilih', 'Persentase']
    )


def calculate_ctt_metrics(X_mat, item_cols):
    """Menghitung metrik CTT per butir soal dengan efisiensi memori tinggi."""
    N, K = X_mat.shape

    total_scores = X_mat.sum(axis=1, dtype=np.float32)
    std_total = total_scores.std(ddof=1)

    p_vals = X_mat.mean(axis=0, dtype=np.float32)
    std_items = X_mat.std(axis=0, ddof=1, dtype=np.float32)

    item_stats = []

    if std_total > 0:
        mean_X = p_vals
        mean_Y = total_scores.mean()
        cov_XY = ((X_mat - mean_X) * (total_scores[:, np.newaxis] - mean_Y)).mean(axis=0)
        cov_XY = cov_XY * (N / (N - 1)) if N > 1 else cov_XY

        with np.errstate(divide='ignore', invalid='ignore'):
            r_vals = cov_XY / (std_items * std_total)
            r_vals = np.nan_to_num(r_vals, nan=0.0)
    else:
        r_vals = np.zeros(K, dtype=np.float32)

    for i in range(K):
        item_name = str(item_cols[i])
        p_val = float(p_vals[i])
        r_val = float(r_vals[i])

        if p_val < 0.30:
            kategori_p = 'Sukar'
        elif p_val <= 0.70:
            kategori_p = 'Sedang'
        else:
            kategori_p = 'Mudah'

        if r_val >= 0.40:
            kategori_r = 'Sangat Baik'
        elif r_val >= 0.30:
            kategori_r = 'Baik'
        elif r_val >= 0.20:
            kategori_r = 'Cukup (Perlu Revisi)'
        else:
            kategori_r = 'Buruk (Dibuang/Revisi Total)'

        # Penentuan Status Rekomendasi
        if r_val >= 0.30:
            rekomendasi = 'Diterima Baik'
        elif r_val >= 0.20:
            rekomendasi = 'Direvisi'
        else:
            rekomendasi = 'Dibuang / Diganti'

        item_stats.append({
            'Kode_Soal': item_name,
            'Item': item_name,
            'Tingkat_Kesukaran_p': round(p_val, 3),
            'Kategori_Kesukaran': kategori_p,
            'Daya_Beda_r': round(r_val, 3),
            'Kategori_Daya_Beda': kategori_r,
            'Rekomendasi': rekomendasi,
        })

    return pd.DataFrame(item_stats)


def run_ctt_analysis(df_matrix, df_respon=None, df_kunci=None):
    """Fungsi utama analisis CTT."""
    item_cols = get_item_columns(df_matrix)
    n_items = len(item_cols)
    n_persons = len(df_matrix)

    # Konversi ke NumPy uint8 agar hemat RAM
    X_mat = df_matrix[item_cols].fillna(0).to_numpy(dtype=np.uint8)
    skor_mentah = X_mat.sum(axis=1, dtype=np.uint32)

    df_result = df_matrix.copy()
    df_result['Skor_Mentah'] = skor_mentah

    if n_items > 0:
        df_result['Nilai_Konversi'] = np.round((skor_mentah / n_items) * 100, 2)
    else:
        df_result['Nilai_Konversi'] = 0.0

    konversi_scores = df_result['Nilai_Konversi']

    cronbach_alpha = 0.0
    if n_items > 1 and n_persons > 1:
        item_variances = X_mat.var(axis=0, ddof=1, dtype=np.float32).sum()
        total_variance = float(np.var(skor_mentah, ddof=1))

        if total_variance > 0:
            val_alpha = (n_items / (n_items - 1)) * (
                1.0 - (item_variances / total_variance)
            )
            cronbach_alpha = round(float(val_alpha), 3)

    df_item_stats = calculate_ctt_metrics(X_mat, item_cols)
    df_distractor = calculate_distractor_analysis(df_respon, df_kunci, df_result)

    mean_val = round(float(konversi_scores.mean()), 2) if len(konversi_scores) > 0 else 0.0
    std_val = round(float(konversi_scores.std()), 2) if len(konversi_scores) > 0 else 0.0
    max_val = round(float(konversi_scores.max()), 2) if len(konversi_scores) > 0 else 0.0
    min_val = round(float(konversi_scores.min()), 2) if len(konversi_scores) > 0 else 0.0
    med_val = round(float(konversi_scores.median()), 2) if len(konversi_scores) > 0 else 0.0

    summary_stats = {
        'cronbach_alpha': cronbach_alpha,
        'n_peserta': n_persons,
        'n_soal': n_items,
        'n_items': n_items,
        'mean_score': mean_val,
        'std_score': std_val,
        'max_score': max_val,
        'min_score': min_val,
        'median_score': med_val,
        'Jumlah_Peserta': n_persons,
        'Rata_Rata': mean_val,
        'Standar_Deviasi': std_val,
        'Nilai_Tertinggi': max_val,
        'Nilai_Terendah': min_val,
        'Median': med_val,
    }

    # Pembersihan kolom akhir agar tidak ada duplikasi nama kolom
    df_result = df_result.loc[:, ~df_result.columns.duplicated()].copy()

    return {
        'cronbach_alpha': cronbach_alpha,
        'item_stats': df_item_stats,
        'distractor_stats': df_distractor,
        'summary': summary_stats,
        'df_result': df_result,
    }