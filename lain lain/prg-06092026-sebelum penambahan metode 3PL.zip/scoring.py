import numpy as np
import pandas as pd


def process_scoring(df_respon, df_kunci):
    """Memproses jawaban peserta menjadi matriks skor (0 / 1 / NaN).

    Mengisi 'np.nan' untuk soal yang tidak diujikan/dikerjakan oleh peserta
    agar kalkulasi rata-rata psikometri CTT/IRT akurat dan tidak nol.
    """
    df_respon.columns = df_respon.columns.astype(str).str.strip().str.lower()
    df_kunci.columns = df_kunci.columns.astype(str).str.strip().str.lower()

    # Deteksi kolom ID Peserta
    id_col_respon = None
    for col in ["username", "id_peserta", "id", "nisn", "no_peserta", "nama"]:
        if col in df_respon.columns:
            id_col_respon = col
            break
    if not id_col_respon:
        id_col_respon = df_respon.columns[0]

    # Deteksi kolom Kode Soal & Kunci Jawaban
    soal_col_kunci = None
    kunci_col_kunci = None
    for col in ["kode_soal", "id_soal", "soal", "no_soal"]:
        if col in df_kunci.columns:
            soal_col_kunci = col
            break
    for col in ["kunci", "kunci_jawaban", "jawaban", "key"]:
        if col in df_kunci.columns:
            kunci_col_kunci = col
            break

    if not soal_col_kunci:
        soal_col_kunci = df_kunci.columns[0]
    if not kunci_col_kunci:
        kunci_col_kunci = (
            df_kunci.columns[1] if len(df_kunci.columns) > 1 else df_kunci.columns[0]
        )

    # Dictionary Kunci Jawaban
    kunci_dict = dict(
        zip(
            df_kunci[soal_col_kunci].astype(str).str.strip(),
            df_kunci[kunci_col_kunci].astype(str).str.strip().str.upper(),
        )
    )

    # Kasus A: Format List String ('list_soal' & 'respon' dipisah koma)
    if "list_soal" in df_respon.columns and "respon" in df_respon.columns:
        # Ekstrak HANYA kode soal yang benar-benar ada di dalam data respon
        used_items = set()
        for val_soal in df_respon["list_soal"].dropna():
            for s in str(val_soal).split(","):
                s_clean = s.strip()
                if s_clean and s_clean in kunci_dict:
                    used_items.add(s_clean)

        # Matriks kolom hanya dibuat sebanyak soal yang diujikan (misal: 25 butir)
        item_cols = sorted(list(used_items))
        item_to_idx = {item: i for i, item in enumerate(item_cols)}

        n_rows = len(df_respon)
        n_items = len(item_cols)

        # Inisialisasi dengan NaN untuk membedakan soal tidak dikerjakan
        score_matrix = np.full((n_rows, n_items), np.nan, dtype=np.float32)
        jumlah_soal_list = np.zeros(n_rows, dtype=np.uint16)

        raw_list_soal = df_respon["list_soal"].values
        raw_respon = df_respon["respon"].values

        for idx in range(n_rows):
            val_soal = raw_list_soal[idx]
            val_resp = raw_respon[idx]

            str_soal = "" if pd.isna(val_soal) else str(val_soal).strip()
            str_resp = "" if pd.isna(val_resp) else str(val_resp).strip()

            soal_list = [s.strip() for s in str_soal.split(",") if s.strip()]
            respon_list = [r.strip().upper() for r in str_resp.split(",") if r.strip()]

            jumlah_soal_list[idx] = len(soal_list)

            for s_code, resp in zip(soal_list, respon_list):
                if s_code in item_to_idx:
                    kunci = kunci_dict.get(s_code)
                    if kunci is not None:
                        # Jika menjawab sesuai kunci -> 1, jika beda -> 0
                        score_matrix[idx, item_to_idx[s_code]] = 1.0 if resp == kunci else 0.0

        df_matrix = pd.DataFrame(score_matrix, columns=item_cols)
        df_matrix.insert(0, id_col_respon, df_respon[id_col_respon].values)
        df_matrix["Jumlah_Soal"] = jumlah_soal_list

    # Kasus B: Format 'Long'
    elif "kode_soal" in df_respon.columns and "jawaban" in df_respon.columns:
        df_respon["kode_soal_clean"] = df_respon["kode_soal"].astype(str).str.strip()
        df_respon["jawaban_clean"] = (
            df_respon["jawaban"].astype(str).str.strip().str.upper()
        )
        df_respon["kunci_true"] = df_respon["kode_soal_clean"].map(kunci_dict)

        df_respon["skor"] = np.where(
            (df_respon["jawaban_clean"] == df_respon["kunci_true"])
            & (df_respon["jawaban_clean"] != ""),
            1.0,
            0.0,
        )

        jml_soal_per_user = df_respon.groupby(id_col_respon)[
            "kode_soal_clean"
        ].nunique()

        df_matrix = (
            df_respon.pivot(
                index=id_col_respon, columns="kode_soal_clean", values="skor"
            )
            .reset_index()
        )

        df_matrix["Jumlah_Soal"] = (
            df_matrix[id_col_respon].map(jml_soal_per_user).fillna(0).astype(int)
        )

    # Kasus C: Format 'Wide'
    else:
        df_matrix = pd.DataFrame()
        df_matrix[id_col_respon] = df_respon[id_col_respon]

        soal_cols = []
        for col in df_respon.columns:
            if col == id_col_respon:
                continue

            col_clean = str(col).strip()
            if col_clean in kunci_dict:
                soal_cols.append(col_clean)
                kunci_val = kunci_dict[col_clean]
                resp_val = df_respon[col].astype(str).str.strip().str.upper()
                df_matrix[col_clean] = np.where(resp_val == kunci_val, 1.0, 0.0)

        df_matrix["Jumlah_Soal"] = len(soal_cols)

    # Mencegah duplikat kolom
    df_matrix = df_matrix.loc[:, ~df_matrix.columns.duplicated()].copy()

    # Hitung Skor Mentah & Nilai Konversi
    non_item = [
        id_col_respon,
        "username",
        "skor_mentah",
        "nilai_konversi",
        "jumlah_soal",
    ]
    item_cols = [c for c in df_matrix.columns if c.lower() not in non_item]

    # Abaikan NaN saat penjumlahan skor mentah
    df_matrix["skor_mentah"] = df_matrix[item_cols].sum(axis=1, skipna=True).astype(int)

    df_matrix["Nilai_Konversi"] = np.where(
        df_matrix["Jumlah_Soal"] > 0,
        (df_matrix["skor_mentah"] / df_matrix["Jumlah_Soal"]) * 100.0,
        0.0,
    ).round(2)

    return df_matrix


def calculate_person_fit(df_matrix, df_params, b_col="b"):
    """Menghitung indeks fit peserta (Outfit MSQ) secara hemat memori."""
    id_col = df_matrix.columns[0]
    non_item = [
        id_col,
        "username",
        "skor_mentah",
        "skormentah",
        "jumlah_soal",
        "nilai_konversi",
    ]
    item_cols = [c for c in df_matrix.columns if c.lower() not in non_item]

    item_map = dict(zip(df_params[df_params.columns[0]].astype(str), df_params[b_col]))
    b_vec = np.array([item_map.get(str(c), 0.0) for c in item_cols])

    X = df_matrix[item_cols].to_numpy(dtype=np.float32)

    # Perbaikan: Menggunakan np.nansum (tanpa garis bawah)
    total_scores = np.nansum(X, axis=1)
    n_items_valid = np.sum(~np.isnan(X), axis=1)
    n_items_valid = np.where(n_items_valid == 0, 1, n_items_valid)

    p_scores = np.clip(total_scores / n_items_valid, 0.01, 0.99)
    theta_vec = np.log(p_scores / (1.0 - p_scores))

    theta_mat = theta_vec[:, np.newaxis]
    P = 1.0 / (1.0 + np.exp(-(theta_mat - b_vec)))
    P = np.clip(P, 1e-4, 0.9999)

    W = P * (1.0 - P)
    Z_sq = np.nan_to_num(((X - P) ** 2) / W, nan=0.0)
    outfit_msq = Z_sq.mean(axis=1)

    status = np.where(
        (outfit_msq >= 0.5) & (outfit_msq <= 1.5),
        "Pola Normal",
        np.where(outfit_msq > 1.5, "Menebak / Anomali", "Terlalu Menentu"),
    )

    df_res = pd.DataFrame({
        id_col: df_matrix[id_col],
        "Outfit_MSQ": np.round(outfit_msq, 2),
        "Status_Pola_Jawab": status,
    })

    return df_res.loc[:, ~df_res.columns.duplicated()].copy()