# db_helper.py
import os
import urllib.parse
import pandas as pd
from sqlalchemy import create_engine, text

# Konfigurasi Koneksi MySQL
MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_USER = os.getenv("MYSQL_USER", "root")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "db_psikometri")
MYSQL_PORT = os.getenv("MYSQL_PORT", "3306")


def get_db_connection():
    """Membuat SQLAlchemy Engine untuk MySQL."""
    try:
        # Encode password untuk mengantisipasi karakter khusus (@, :, / dll)
        encoded_password = urllib.parse.quote_plus(MYSQL_PASSWORD)
        connection_string = (
            f"mysql+pymysql://{MYSQL_USER}:{encoded_password}"
            f"@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}"
        )
        engine = create_engine(connection_string, pool_recycle=3600)
        return engine
    except Exception as e:
        print(f"Gagal koneksi ke database: {e}")
        return None


def init_db_tables() -> bool:
    """Mempersiapkan struktur tabel MySQL jika belum ada."""
    engine = get_db_connection()
    if engine is None:
        return False

    try:
        with engine.begin() as conn:
            # 1. Tabel Peserta & Skor
            conn.execute(
                text(
                    """
                CREATE TABLE IF NOT EXISTS tb_peserta_skor (
                    id_peserta VARCHAR(100) PRIMARY KEY,
                    username VARCHAR(100),
                    nama_sekolah VARCHAR(255),
                    kode_sekolah VARCHAR(50),
                    nama_kabupaten VARCHAR(100),
                    nama_provinsi VARCHAR(100),
                    kode_provinsi VARCHAR(10),
                    skor_mentah FLOAT,
                    skor_konversi_ctt FLOAT,
                    skor_konversi_rasch FLOAT,
                    skor_konversi_1pl FLOAT,
                    skor_konversi_2pl FLOAT,
                    skor_konversi_3pl FLOAT,
                    Jumlah_Soal INT
                );
            """
                )
            )

            # 2. Tabel Parameter Soal
            conn.execute(
                text(
                    """
                CREATE TABLE IF NOT EXISTS tb_soal_parameter (
                    kode_soal VARCHAR(100) PRIMARY KEY,
                    tingkat_kesukaran_ctt FLOAT,
                    daya_beda_ctt FLOAT,
                    rekomendasi VARCHAR(100),
                    b_rasch FLOAT,
                    b_1pl FLOAT,
                    a_2pl FLOAT,
                    b_2pl FLOAT,
                    a_3pl FLOAT,
                    b_3pl FLOAT,
                    c_3pl FLOAT
                );
            """
                )
            )

            # 3. Tabel Ringkasan Model
            conn.execute(
                text(
                    """
                CREATE TABLE IF NOT EXISTS tb_model_summary (
                    metode_model VARCHAR(20) PRIMARY KEY,
                    reliabilitas FLOAT,
                    log_likelihood FLOAT,
                    aic FLOAT,
                    bic FLOAT
                );
            """
                )
            )

            # 4. Tabel Agregasi Sekolah
            conn.execute(
                text(
                    """
                CREATE TABLE IF NOT EXISTS tb_sekolah_agregasi (
                    kode_sekolah VARCHAR(50) PRIMARY KEY,
                    nama_sekolah VARCHAR(255),
                    nama_kabupaten VARCHAR(100),
                    nama_provinsi VARCHAR(100),
                    jumlah_peserta INT,
                    rata_skor_mentah FLOAT,
                    rata_skor_ctt FLOAT,
                    rata_skor_rasch FLOAT,
                    rata_skor_1pl FLOAT,
                    rata_skor_2pl FLOAT,
                    rata_skor_3pl FLOAT
                );
            """
                )
            )

            # Migration/Alter aman tanpa tergantung 'IF NOT EXISTS'
            alter_commands = [
                ("tb_peserta_skor", "skor_konversi_1pl", "FLOAT"),
                ("tb_peserta_skor", "Jumlah_Soal", "INT"),
                ("tb_soal_parameter", "b_1pl", "FLOAT"),
                ("tb_soal_parameter", "rekomendasi", "VARCHAR(100)"),
                ("tb_sekolah_agregasi", "rata_skor_1pl", "FLOAT"),
            ]

            for table, column, col_type in alter_commands:
                # Cek dulu apakah kolom sudah ada
                check_query = text(
                    f"SHOW COLUMNS FROM {table} LIKE '{column}';"
                )
                res = conn.execute(check_query).fetchone()
                if not res:
                    conn.execute(
                        text(f"ALTER TABLE {table} ADD COLUMN {column} {col_type};")
                    )

        return True
    except Exception as e:
        print(f"Gagal inisialisasi tabel database: {e}")
        return False


def prepare_and_save_analysis(
    df_peserta: pd.DataFrame,
    df_soal: pd.DataFrame,
    df_summary: pd.DataFrame,
    df_sekolah: pd.DataFrame,
) -> tuple[bool, str]:
    """Menyimpan seluruh DataFrame hasil analisis ke MySQL Server."""
    try:
        engine = get_db_connection()
        if engine is None:
            return False, "Tidak dapat terhubung ke MySQL Server."

        if not init_db_tables():
            return False, "Gagal membuat/menyiapkan tabel database."

        with engine.begin() as conn:
            # Opsional: Jika ingin mengosongkan data lama sebelum insert baru
            # conn.execute(text("TRUNCATE TABLE tb_peserta_skor;"))

            # Gunakan if_exists="append" agar struktur Primary Key dari DDL tidak hilang
            if df_peserta is not None and not df_peserta.empty:
                df_peserta.to_sql(
                    "tb_peserta_skor", conn, if_exists="append", index=False
                )

            if df_soal is not None and not df_soal.empty:
                df_soal.to_sql(
                    "tb_soal_parameter", conn, if_exists="append", index=False
                )

            if df_summary is not None and not df_summary.empty:
                df_summary.to_sql(
                    "tb_model_summary", conn, if_exists="append", index=False
                )

            if df_sekolah is not None and not df_sekolah.empty:
                df_sekolah.to_sql(
                    "tb_sekolah_agregasi", conn, if_exists="append", index=False
                )

        return True, "Berhasil menyimpan ke MySQL Server."
    except Exception as e:
        return False, str(e)