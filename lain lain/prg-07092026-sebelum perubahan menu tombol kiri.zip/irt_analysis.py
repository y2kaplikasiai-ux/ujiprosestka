# irt_analysis.py
import numpy as np
import pandas as pd


def _sigmoid(x):
    """Fungsi aktivasi numerik aman dari overflow/underflow."""
    return 1.0 / (1.0 + np.exp(-np.clip(x, -15, 15)))


def get_item_columns(df):
    """Mengekstrak HANYA kolom kode soal untuk analisis IRT."""
    non_item_keywords = [
        'username',
        'tahun',
        'kode_jenjang',
        'kode_mapel',
        'kode_paket',
        'list_soal',
        'respon',
        'skor_mentah',
        'nilai_konversi',
        'no',
        'no.',
        'id',
        'nama',
        'sekolah',
        'npsn',
        'kelas',
        'unnamed',
        'jumlah_soal_dikerjakan',
        'jumlah_soal',
    ]

    item_cols = [
        col
        for col in df.columns
        if not any(kw in str(col).strip().lower() for kw in non_item_keywords)
    ]
    return item_cols


def run_irt_analysis(df_matrix, model_type='1PL'):
    """
    Menjalankan estimasi IRT cepat berbasis Vektorisasi NumPy (Rasch, 1PL, 2PL, 3PL).
    Proses selesai dalam waktu beberapa detik untuk data berukuran besar.
    """
    df = df_matrix.copy()

    # 1. Dapatkan kolom item murni
    item_cols = get_item_columns(df)

    # 2. Ambil ID Peserta & paksa ke Tipe String
    if 'username' in df.columns:
        user_ids = df['username'].astype(str).str.strip()
    elif 'Username' in df.columns:
        user_ids = df['Username'].astype(str).str.strip()
    elif 'id' in df.columns:
        user_ids = df['id'].astype(str).str.strip()
    else:
        user_ids = df.index.astype(str)

    # 3. Konversi matriks respon ke numerik float
    X_df = df[item_cols].apply(pd.to_numeric, errors='coerce').fillna(0)
    X = X_df.to_numpy(dtype=float)
    n_persons, n_items = X.shape

    if n_items == 0 or n_persons == 0:
        raise ValueError("Data tidak memiliki butir soal atau peserta yang valid.")

    # 4. Hitung Proporsi Benar Item (p_i) & Skor Mentah Peserta
    p_i = np.clip(np.nanmean(X, axis=0), 0.005, 0.995)
    skor_mentah = np.nansum(X, axis=1)

    # Estimasi Parameter Kesukaran (b)
    b_params = np.log((1.0 - p_i) / p_i)
    c_params = np.zeros(n_items)  # Default pseudo-guessing

    # --- LOGIKA BERDASARKAN MODEL_TYPE ---
    m_type_str = str(model_type).upper()

    if m_type_str == 'RASCH':
        a_params = np.ones(n_items)
        p_person = np.clip(skor_mentah / max(n_items, 1), 0.005, 0.995)
        theta = np.log(p_person / (1.0 - p_person))
        num_params = n_items + n_persons  # b_i + theta_j

    elif m_type_str == '1PL':
        std_skor = np.std(skor_mentah)
        if std_skor > 0:
            p_i_safe = np.where(p_i * (1.0 - p_i) == 0, 1e-5, p_i * (1.0 - p_i))
            r_bis = (np.mean(X * skor_mentah[:, None], axis=0) - p_i * np.mean(skor_mentah)) / (std_skor * np.sqrt(p_i_safe))
            a_common = np.clip(np.nanmean(r_bis), 0.2, 2.5)
        else:
            a_common = 1.0

        a_params = np.full(n_items, a_common)
        p_person = np.clip(skor_mentah / max(n_items, 1), 0.005, 0.995)
        theta = np.log(p_person / (1.0 - p_person)) / a_common
        num_params = n_items + 1 + n_persons  # b_i + a_common + theta_j

    elif m_type_str == '3PL':
        std_skor = np.std(skor_mentah)
        if std_skor > 0:
            p_i_safe = np.where(p_i * (1.0 - p_i) == 0, 1e-5, p_i * (1.0 - p_i))
            r_bis = (np.mean(X * skor_mentah[:, None], axis=0) - p_i * np.mean(skor_mentah)) / (std_skor * np.sqrt(p_i_safe))
            a_params = np.clip(np.nan_to_num(r_bis, nan=1.0), 0.2, 2.5)
        else:
            a_params = np.ones(n_items)

        bottom_idx = np.argsort(skor_mentah)[: max(1, int(n_persons * 0.10))]
        c_params = np.clip(np.mean(X[bottom_idx, :], axis=0), 0.0, 0.25)

        weighted_scores = np.dot(X, a_params)
        max_weighted = np.sum(a_params)
        p_person_weighted = np.clip(weighted_scores / max(max_weighted, 1.0), 0.005, 0.995)
        theta = np.log(p_person_weighted / (1.0 - p_person_weighted))
        num_params = (3 * n_items) + n_persons  # a_i + b_i + c_i + theta_j

    else:  # Default '2PL'
        std_skor = np.std(skor_mentah)
        if std_skor > 0:
            p_i_safe = np.where(p_i * (1.0 - p_i) == 0, 1e-5, p_i * (1.0 - p_i))
            r_bis = (np.mean(X * skor_mentah[:, None], axis=0) - p_i * np.mean(skor_mentah)) / (std_skor * np.sqrt(p_i_safe))
            a_params = np.clip(np.nan_to_num(r_bis, nan=1.0), 0.2, 2.5)
        else:
            a_params = np.ones(n_items)

        weighted_scores = np.dot(X, a_params)
        max_weighted = np.sum(a_params)
        p_person_weighted = np.clip(weighted_scores / max(max_weighted, 1.0), 0.005, 0.995)
        theta = np.log(p_person_weighted / (1.0 - p_person_weighted))
        num_params = (2 * n_items) + n_persons  # a_i + b_i + theta_j

    # Kategori b
    kat_conditions = [b_params > 1.0, b_params < -1.0]
    kat_choices = ['Sukar', 'Mudah']
    kategori_b = np.select(kat_conditions, kat_choices, default='Sedang')

    # Probabilitas & Standard Error of Measurement (SEM) per Peserta
    logits = a_params[None, :] * (theta[:, None] - b_params[None, :])
    P_val = c_params[None, :] + (1.0 - c_params[None, :]) * _sigmoid(logits)
    P_val_clipped = np.clip(P_val, 1e-7, 1.0 - 1e-7)

    info_per_person = np.sum((a_params[None, :] ** 2) * P_val * (1.0 - P_val), axis=1)
    sem_list = np.where(info_per_person > 0, 1.0 / np.sqrt(info_per_person), 0.999)

    # --- HITUNG STATISTIK FIT MODEL (LOG-LIKELIHOOD, AIC, BIC, RELIABILITY) ---
    log_likelihood = float(np.sum(X * np.log(P_val_clipped) + (1.0 - X) * np.log(1.0 - P_val_clipped)))
    aic = float(2 * num_params - 2 * log_likelihood)
    bic = float(num_params * np.log(max(n_persons * n_items, 1)) - 2 * log_likelihood)

    var_theta = np.var(theta)
    mean_sem2 = np.mean(sem_list ** 2)
    reliability = float(np.clip((var_theta - mean_sem2) / max(var_theta, 1e-5), 0.0, 0.99))

    df_item_params = pd.DataFrame({
        'Item': [str(c) for c in item_cols],
        'Kode_Soal': [str(c) for c in item_cols],
        'a': np.round(a_params, 3),
        'b': np.round(b_params, 3),
        'c': np.round(c_params, 3),
        'Daya_Beda (a)': np.round(a_params, 3),
        'Tingkat_Kesukaran (b)': np.round(b_params, 3),
        'Tebakan_Pseudos (c)': np.round(c_params, 3),
        'Tingkat_Kesukaran': kategori_b,
    })

    nilai_konversi = (skor_mentah / max(n_items, 1)) * 100.0

    df_person_params = pd.DataFrame({
        'ID Peserta': user_ids.values,
        'username': user_ids.values,
        'Skor Mentah': skor_mentah.astype(int),
        'Kemampuan (Theta θ)': np.round(theta, 3),
        'Nilai Konversi': np.round(nilai_konversi, 2),
        'SEM': np.round(sem_list, 3),
    })

    df_person_params['ID Peserta'] = df_person_params['ID Peserta'].astype(str)
    df_person_params['username'] = df_person_params['username'].astype(str)

    fit_stats = {
        'reliability': round(reliability, 4),
        'log_likelihood': round(log_likelihood, 2),
        'aic': round(aic, 2),
        'bic': round(bic, 2),
    }

    return {
        'item_params': df_item_params,
        'person_params': df_person_params,
        'person_fit': df_person_params,
        'fit_stats': fit_stats,
        'model': model_type,
        'n_total': len(df_matrix),
        'n_sample': n_persons,
    }