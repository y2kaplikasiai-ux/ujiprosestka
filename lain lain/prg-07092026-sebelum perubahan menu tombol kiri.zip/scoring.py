# scoring.py
import numpy as np
import pandas as pd
import pymysql
from sqlalchemy import create_engine, text

# Konfigurasi Server MySQL Lokal
DB_HOST = "localhost"
DB_USER = "root"
DB_PASS = ""
DB_NAME = "db_psikometri"
DB_PORT = 3306

DB_URL = f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"


def reset_and_create_tables():
    """
    Menghapus tabel lama jika ada (DROP), lalu membuat tabel baru lengkap dengan 
    tipe data spesifik dan indeksnya dari awal.
    """
    # 1. Cek & Buat Database jika belum ada
    conn = pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASS, port=DB_PORT)
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{DB_NAME}`;")
        conn.commit()
    finally:
        conn.close()

    # 2. Re-create Tabel dan Indeks secara terpisah untuk keamanan transaksi
    engine = create_engine(DB_URL)
    
    drop_query = "DROP TABLE IF EXISTS tb_peserta_skor;"
    create_query = """
    CREATE TABLE tb_peserta_skor (
        id_peserta VARCHAR(100) PRIMARY KEY,
        username VARCHAR(100),
        kode_sekolah VARCHAR(50),
        nama_sekolah VARCHAR(255),
        kode_provinsi VARCHAR(10),
        nama_provinsi VARCHAR(100),
        skor_mentah FLOAT NULL,
        skor_konversi_ctt FLOAT NULL,
        skor_konversi_rasch FLOAT NULL,
        skor_konversi_1pl FLOAT NULL,
        skor_konversi_2pl FLOAT NULL,
        skor_konversi_3pl FLOAT NULL,
        Jumlah_Soal INT NULL,
        INDEX idx_sekolah (kode_sekolah),
        INDEX idx_provinsi (kode_provinsi)
    );
    """
    
    with engine.connect() as connection:
        connection.execute(text(drop_query))
        connection.execute(text(create_query))
        connection.commit()

    return engine


def scale_theta_to_100(theta_series):
    """
    Helper fallback untuk mengonversi nilai Theta IRT (-4 s/d +4) ke Skala Standar (0 - 100).
    """
    if theta_series is None or theta_series.empty:
        return pd.Series(dtype=float)

    theta_clean = pd.to_numeric(theta_series, errors="coerce")
    t_min = theta_clean.min()
    t_max = theta_clean.max()

    if pd.notna(t_min) and pd.notna(t_max) and t_max != t_min:
        scaled = ((theta_clean - t_min) / (t_max - t_min)) * 100.0
    else:
        scaled = pd.Series(50.0, index=theta_series.index)

    return scaled.round(2)


def pipeline_proses_dan_simpan_mysql(df_matrix_school, irt_dict):
    """
    Menggabungkan seluruh hasil kalkulasi (CTT & IRT), mereset tabel di database,
    lalu memasukkan data baru ke tabel yang bersih.
    """
    if df_matrix_school is None or df_matrix_school.empty:
        return

    # Reset total tabel & buat skema + indeks baru
    engine = reset_and_create_tables()

    # Deteksi ID Peserta
    id_col = df_matrix_school.columns[0]
    for c in ["username", "user_id", "id_peserta"]:
        if c in df_matrix_school.columns:
            id_col = c
            break

    df_final = pd.DataFrame()
    df_final["id_peserta"] = df_matrix_school[id_col].astype(str).str.strip()
    df_final["username"] = df_final["id_peserta"]

    # Ekstraksi atribut sekolah & wilayah
    df_final["kode_sekolah"] = (
        df_matrix_school["_school_key"]
        if "_school_key" in df_matrix_school.columns
        else df_final["id_peserta"].str[:9]
    )
    df_final["nama_sekolah"] = (
        df_matrix_school["nama_sekolah"]
        if "nama_sekolah" in df_matrix_school.columns
        else df_final["kode_sekolah"]
    )
    df_final["kode_provinsi"] = (
        df_matrix_school["kd_prop"]
        if "kd_prop" in df_matrix_school.columns
        else df_final["id_peserta"].str[1:3]
    )
    df_final["nama_provinsi"] = (
        df_matrix_school["nama_provinsi"]
        if "nama_provinsi" in df_matrix_school.columns
        else df_final["kode_provinsi"]
    )

    # 1. Skor Mentah & Jumlah Soal
    df_final["skor_mentah"] = (
        df_matrix_school["skor_mentah"].astype(float)
        if "skor_mentah" in df_matrix_school.columns
        else np.nan
    )
    df_final["Jumlah_Soal"] = (
        df_matrix_school["Jumlah_Soal"].astype(int)
        if "Jumlah_Soal" in df_matrix_school.columns
        else np.nan
    )

    # 2. Skor CTT
    df_final["skor_konversi_ctt"] = (
        df_matrix_school["Nilai_Konversi"].astype(float).round(2)
        if "Nilai_Konversi" in df_matrix_school.columns
        else np.nan
    )

    # 3. Skor IRT (Rasch, 1PL, 2PL, 3PL)
    for model_key in ["rasch", "1pl", "2pl", "3pl"]:
        col_db_name = f"skor_konversi_{model_key}"
        if model_key in irt_dict and "df_person" in irt_dict[model_key]:
            df_person = irt_dict[model_key]["df_person"]
            if not df_person.empty:
                # Prioritaskan Nilai_Scaled yang sudah terkonversi
                score_series = None
                if "Nilai_Scaled" in df_person.columns:
                    score_series = df_person["Nilai_Scaled"]
                else:
                    theta_col = None
                    for c in df_person.columns:
                        c_clean = str(c).lower()
                        if any(k in c_clean for k in ["theta", "kemampuan"]):
                            theta_col = c
                            break
                    if theta_col:
                        score_series = scale_theta_to_100(df_person[theta_col])

                if score_series is not None:
                    # Petakan berdasarkan ID Peserta
                    id_p_col = (
                        "username"
                        if "username" in df_person.columns
                        else df_person.columns[0]
                    )
                    map_score = dict(
                        zip(
                            df_person[id_p_col].astype(str).str.strip(),
                            score_series,
                        )
                    )
                    df_final[col_db_name] = df_final["id_peserta"].map(map_score)
                else:
                    df_final[col_db_name] = np.nan
            else:
                df_final[col_db_name] = np.nan
        else:
            df_final[col_db_name] = np.nan

    # Bersihkan duplikat ID Peserta jika ada
    df_final = df_final.drop_duplicates(subset=["id_peserta"]).copy()

    # Simpan ke tabel yang sudah bersih
    df_final.to_sql(
        name="tb_peserta_skor",
        con=engine,
        if_exists="append",
        index=False,
        chunksize=10000,
    )


def extract_active_soal_from_respon(df_respon):
    """Mengambil semua ID/Kode soal unik yang benar-benar dikerjakan peserta dari 'list_soal'."""
    if "list_soal" not in df_respon.columns:
        return None

    active_soal = set()
    for raw_list in df_respon["list_soal"].dropna():
        items = [s.strip() for s in str(raw_list).split(",") if s.strip()]
        active_soal.update(items)

    return list(active_soal)


def process_scoring(df_respon, df_kunci):
    """Memproses jawaban peserta menjadi matriks skor (0 / 1 / NaN).

    - Nilai 1.0 : Jawaban Benar
    - Nilai 0.0 : Jawaban Salah / Kosong (tetapi soal DIBERIKAN dalam paket peserta)
    - Nilai NaN : Soal TIDAK DIBERIKAN / TIDAK DIUJIKAN kepada peserta
    """
    df_respon = df_respon.copy()
    df_kunci = df_kunci.copy()
    
    df_respon.columns = df_respon.columns.astype(str).str.strip().str.lower()
    df_kunci.columns = df_kunci.columns.astype(str).str.strip().str.lower()

    # Deteksi kolom ID Peserta
    id_col_respon = None
    for col in ["username", "id_peserta", "id", "nisn", "no_peserta", "nama"]:
        if col in df_respon.columns:
            id_col_respon = col
            break
    if not id_col_respon:
        id_col_respon = df_respon.columns[0]

    # Deteksi kolom Kode Paket jika ada
    kode_paket_col = None
    for col in ["kode_paket", "kd_paket", "paket"]:
        if col in df_respon.columns:
            kode_paket_col = col
            break

    # Deteksi kolom Kode Soal & Kunci Jawaban
    soal_col_kunci = None
    kunci_col_kunci = None
    for col in ["kode_soal", "id_soal", "soal", "no_soal", "kd_soal"]:
        if col in df_kunci.columns:
            soal_col_kunci = col
            break
    for col in ["kunci", "kunci_jawaban", "jawaban", "key"]:
        if col in df_kunci.columns:
            kunci_col_kunci = col
            break

    if not soal_col_kunci:
        soal_col_kunci = df_kunci.columns[0]
    if not kunci_col_kunci:
        kunci_col_kunci = (
            df_kunci.columns[1] if len(df_kunci.columns) > 1 else df_kunci.columns[0]
        )

    # Dictionary Kunci Jawaban
    kunci_dict = dict(
        zip(
            df_kunci[soal_col_kunci].astype(str).str.strip(),
            df_kunci[kunci_col_kunci].astype(str).str.strip().str.upper(),
        )
    )

    # KASUS A: Format List String ('list_soal' & 'respon' dipisah koma)
    if "list_soal" in df_respon.columns and "respon" in df_respon.columns:
        used_items = sorted(list(kunci_dict.keys()))
        item_to_idx = {item: i for i, item in enumerate(used_items)}

        n_rows = len(df_respon)
        n_items = len(used_items)

        # Inisialisasi awal matriks dengan np.nan ( default = TIDAK DIBERIKAN )
        score_matrix = np.full((n_rows, n_items), np.nan, dtype=np.float32)
        jumlah_soal_list = np.zeros(n_rows, dtype=np.uint16)

        raw_list_soal = df_respon["list_soal"].values
        raw_respon = df_respon["respon"].values

        for idx in range(n_rows):
            val_soal = raw_list_soal[idx]
            val_resp = raw_respon[idx]

            str_soal = "" if pd.isna(val_soal) else str(val_soal).strip()
            str_resp = "" if pd.isna(val_resp) else str(val_resp).strip()

            soal_list = [s.strip() for s in str_soal.split(",") if s.strip()]
            respon_list = [r.strip().upper() for r in str_resp.split(",")]

            jumlah_soal_list[idx] = len(soal_list)

            # Hanya isi nilai (0.0 atau 1.0) untuk soal yang DIBERIKAN kepada peserta
            for pos, s_code in enumerate(soal_list):
                if s_code in item_to_idx:
                    resp = respon_list[pos] if pos < len(respon_list) else ""
                    kunci = kunci_dict.get(s_code)

                    if kunci is not None:
                        score_matrix[idx, item_to_idx[s_code]] = (
                            1.0 if (resp != "" and resp == kunci) else 0.0
                        )

        df_matrix = pd.DataFrame(score_matrix, columns=used_items)
        df_matrix.insert(0, id_col_respon, df_respon[id_col_respon].values)
        if kode_paket_col:
            df_matrix.insert(1, "kode_paket", df_respon[kode_paket_col].values)
        df_matrix["Jumlah_Soal"] = jumlah_soal_list

    # KASUS B: Format 'Long'
    elif "kode_soal" in df_respon.columns and "jawaban" in df_respon.columns:
        df_respon["kode_soal_clean"] = df_respon["kode_soal"].astype(str).str.strip()
        df_respon["jawaban_clean"] = (
            df_respon["jawaban"].astype(str).str.strip().str.upper()
        )
        df_respon["kunci_true"] = df_respon["kode_soal_clean"].map(kunci_dict)

        df_respon["skor"] = np.where(
            df_respon["jawaban_clean"] == df_respon["kunci_true"],
            1.0,
            0.0,
        )

        jml_soal_per_user = df_respon.groupby(id_col_respon)[
            "kode_soal_clean"
        ].nunique()

        # Pivot otomatis memberikan NaN untuk kombinasi user-soal yang tidak diujikan
        df_matrix = (
            df_respon.pivot(
                index=id_col_respon, columns="kode_soal_clean", values="skor"
            ).reset_index()
        )

        if kode_paket_col:
            paket_map = df_respon.groupby(id_col_respon)[kode_paket_col].first()
            df_matrix.insert(1, "kode_paket", df_matrix[id_col_respon].map(paket_map))

        df_matrix["Jumlah_Soal"] = (
            df_matrix[id_col_respon].map(jml_soal_per_user).fillna(0).astype(int)
        )

    # KASUS C: Format 'Wide'
    else:
        df_matrix = pd.DataFrame()
        df_matrix[id_col_respon] = df_respon[id_col_respon]

        if kode_paket_col:
            df_matrix["kode_paket"] = df_respon[kode_paket_col]

        soal_cols = []
        for col in df_respon.columns:
            if col in [id_col_respon, kode_paket_col]:
                continue

            col_clean = str(col).strip()
            if col_clean in kunci_dict:
                soal_cols.append(col_clean)
                kunci_val = kunci_dict[col_clean]
                resp_val = df_respon[col].astype(str).str.strip().str.upper()

                # Membedakan antara null/tidak diujikan (NaN) dan tidak dijawab/salah (0.0)
                df_matrix[col_clean] = np.where(
                    df_respon[col].isna(),
                    np.nan,
                    np.where(resp_val == kunci_val, 1.0, 0.0),
                )

        df_matrix["Jumlah_Soal"] = df_matrix[soal_cols].notna().sum(axis=1)

    df_matrix = df_matrix.loc[:, ~df_matrix.columns.duplicated()].copy()

    # Hitung Skor Mentah & Nilai Konversi (Mengabaikan NaN)
    non_item = [
        id_col_respon,
        "username",
        "kode_paket",
        "skor_mentah",
        "nilai_konversi",
        "jumlah_soal",
    ]
    item_cols = [c for c in df_matrix.columns if c.lower() not in non_item]

    df_matrix["skor_mentah"] = df_matrix[item_cols].sum(axis=1, skipna=True).astype(int)

    df_matrix["Nilai_Konversi"] = np.where(
        df_matrix["Jumlah_Soal"] > 0,
        (df_matrix["skor_mentah"] / df_matrix["Jumlah_Soal"]) * 100.0,
        0.0,
    ).round(2)

    return df_matrix


def calculate_person_fit(df_matrix, df_params, b_col="b"):
    """Menghitung indeks fit peserta (Outfit MSQ)."""
    id_col = df_matrix.columns[0] if (df_matrix is not None and not df_matrix.empty) else "id_peserta"
    
    empty_res = pd.DataFrame(columns=[id_col, "Outfit_MSQ", "Status_Pola_Jawab"])

    if df_matrix is None or df_matrix.empty or df_params is None or df_params.empty:
        return empty_res

    # Kolom non-item (metadata & skor turunan) yang harus disaring
    non_item_cols = [
        id_col, "username", "user_id", "id_peserta", "nama", "tahun", "kode_paket",
        "nama_sekolah", "kode_sekolah", "nama_kabupaten", "nama_provinsi", "kode_provinsi",
        "nama_sekolah_master", "nama_kabupaten_master", "kd_prop_master", "nama_provinsi_master",
        "skor_mentah", "skormentah", "nilai_konversi", "Nilai_Konversi", 
        "skor_konversi_ctt", "skor_konversi_rasch", "skor_konversi_1pl", 
        "skor_konversi_2pl", "skor_konversi_3pl", "Jumlah_Soal", "jumlah_soal",
        "_school_key", "_prop_key_user", "kd_prop"
    ]
    
    # Filter hanya kolom butir soal
    item_cols = [c for c in df_matrix.columns if c.lower() not in [x.lower() for x in non_item_cols]]

    if not item_cols:
        return empty_res

    item_map = dict(zip(df_params[df_params.columns[0]].astype(str), df_params[b_col]))
    b_vec = np.array([item_map.get(str(c), 0.0) for c in item_cols])

    # Konversi data respons ke float32 secara aman
    df_items = df_matrix[item_cols].apply(pd.to_numeric, errors="coerce")
    X = df_items.to_numpy(dtype=np.float32)

    total_scores = np.nansum(X, axis=1)
    n_items_valid = np.sum(~np.isnan(X), axis=1)
    n_items_valid = np.where(n_items_valid == 0, 1, n_items_valid)

    p_scores = np.clip(total_scores / n_items_valid, 0.01, 0.99)
    theta_vec = np.log(p_scores / (1.0 - p_scores))

    theta_mat = theta_vec[:, np.newaxis]
    P = 1.0 / (1.0 + np.exp(-(theta_mat - b_vec)))
    P = np.clip(P, 1e-4, 0.9999)

    W = P * (1.0 - P)
    Z_sq = np.nan_to_num(((X - P) ** 2) / W, nan=0.0)

    valid_mask = ~np.isnan(X)
    outfit_msq = np.sum(Z_sq * valid_mask, axis=1) / n_items_valid

    status = np.where(
        (outfit_msq >= 0.5) & (outfit_msq <= 1.5),
        "Pola Normal",
        np.where(outfit_msq > 1.5, "Menebak / Anomali", "Terlalu Menentu"),
    )

    df_res = pd.DataFrame({
        id_col: df_matrix[id_col],
        "Outfit_MSQ": np.round(outfit_msq, 2),
        "Status_Pola_Jawab": status,
    })

    return df_res.loc[:, ~df_res.columns.duplicated()].copy()