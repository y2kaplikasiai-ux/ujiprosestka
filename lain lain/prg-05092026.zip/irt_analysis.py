import numpy as np
import pandas as pd


def get_item_columns(df):
  """Mengekstrak HANYA kolom kode soal untuk analisis IRT."""
  non_item_keywords = [
      'username',
      'tahun',
      'kode_jenjang',
      'kode_mapel',
      'kode_paket',
      'list_soal',
      'respon',
      'skor_mentah',
      'nilai_konversi',
      'no',
      'no.',
      'id',
      'nama',
      'sekolah',
      'npsn',
      'kelas',
      'unnamed',
      'jumlah_soal_dikerjakan',
  ]

  item_cols = [
      col
      for col in df.columns
      if not any(kw in str(col).strip().lower() for kw in non_item_keywords)
  ]
  return item_cols


def run_irt_analysis(df_matrix, model_type='1PL'):
  """Menjalankan estimasi IRT super cepat (vektorisasi) & garansi tipe string."""
  df = df_matrix.copy()

  # 1. Dapatkan kolom item murni
  item_cols = get_item_columns(df)

  # 2. Ambil ID Peserta & paksa penuh ke Tipe String
  if 'username' in df.columns:
    user_ids = df['username'].astype(str).str.strip()
  elif 'Username' in df.columns:
    user_ids = df['Username'].astype(str).str.strip()
  elif 'id' in df.columns:
    user_ids = df['id'].astype(str).str.strip()
  else:
    user_ids = df.index.astype(str)

  # 3. Konversi matriks respon ke numerik secara simultan
  X_df = df[item_cols].apply(pd.to_numeric, errors='coerce').fillna(0)
  X = X_df.values
  n_persons, n_items = X.shape

  # 4. Parameter Soal (a & b)
  p_i = np.mean(X, axis=0)
  p_i = np.clip(p_i, 0.01, 0.99)

  b_params = np.log((1 - p_i) / p_i)
  a_params = np.ones(n_items)

  kat_conditions = [b_params > 1.0, b_params < -1.0]
  kat_choices = ['Sukar', 'Mudah']
  kategori_b = np.select(kat_conditions, kat_choices, default='Sedang')

  df_item_params = pd.DataFrame({
      'Item': [str(c) for c in item_cols],
      'a': np.round(a_params, 2),
      'b': np.round(b_params, 3),
      'Tingkat_Kesukaran': kategori_b,
  })

  # 5. Estimasi Kemampuan Peserta (Theta θ)
  skor_mentah = X.sum(axis=1)
  p_person = np.clip(skor_mentah / max(n_items, 1), 0.01, 0.99)
  theta = np.log(p_person / (1 - p_person))
  nilai_konversi = (skor_mentah / max(n_items, 1)) * 100

  # Buat DataFrame Peserta dengan garansi tipe String pada kolom ID
  df_person_params = pd.DataFrame({
      'ID Peserta': user_ids.values,
      'username': user_ids.values,
      'Skor Mentah': skor_mentah.astype(int),
      'Kemampuan (Theta θ)': np.round(theta, 3),
      'Nilai Konversi': np.round(nilai_konversi, 2),
  })

  df_person_params['ID Peserta'] = df_person_params['ID Peserta'].astype(str)
  df_person_params['username'] = df_person_params['username'].astype(str)

  return {
      'item_params': df_item_params,
      'person_params': df_person_params,
      'person_fit': df_person_params,
      'icc_data': {},
  }