# excel_exporter.py
import io
import pandas as pd


def create_excel_report(
    df_matrix,
    df_items,
    df_dist,
    df_params,
    df_persons_irt,
    selected_model="Rasch",
):
  """Membuat laporan ringkasan Excel untuk data agregat/item level

  dan sampel peserta agar tidak melebihi batasan 1.048.576 baris Excel.
  """
  output = io.BytesIO()

  with pd.ExcelWriter(output, engine="openpyxl") as writer:
    # 1. Ringkasan Parameter Soal (IRT)
    if not df_params.empty:
      df_params.to_excel(
          writer, sheet_name=f"Parameter Item ({selected_model})", index=False
      )

    # 2. Statistik Item (CTT)
    if not df_items.empty:
      df_items.to_excel(writer, sheet_name="Statistik Item CTT", index=False)

    # 3. Analisis Pengecoh (Distractor)
    if not df_dist.empty:
      df_dist_export = (
          df_dist.head(1000000) if len(df_dist) > 1048000 else df_dist
      )
      df_dist_export.to_excel(
          writer, sheet_name="Analisis Pengecoh", index=False
      )

    # 4. Sampel Data Peserta (Maksimal 100.000 baris untuk preview di Excel)
    if not df_persons_irt.empty:
      df_sample_person = df_persons_irt.head(100000).copy()
      df_sample_person.to_excel(
          writer, sheet_name="Sampel Peserta (Top 100k)", index=False
      )

  output.seek(0)
  return output.getvalue()


def convert_df_to_csv_bytes(df):
  """Mengonversi DataFrame berukuran besar (jutaan baris) ke byte stream CSV."""
  return df.to_csv(index=False).encode("utf-8")