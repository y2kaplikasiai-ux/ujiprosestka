import numpy as np
import pandas as pd


def extract_active_soal_from_respon(df_respon):
    """Mengambil semua ID/Kode soal unik yang benar-benar dikerjakan peserta dari 'list_soal'."""
    if "list_soal" not in df_respon.columns:
        return None

    active_soal = set()
    for raw_list in df_respon["list_soal"].dropna():
        items = [s.strip() for s in str(raw_list).split(",") if s.strip()]
        active_soal.update(items)

    return list(active_soal)


def process_scoring(df_respon, df_kunci):
    """Memproses jawaban peserta menjadi matriks skor (0 / 1 / NaN).

    - Nilai 1.0 : Jawaban Benar
    - Nilai 0.0 : Jawaban Salah / Kosong (tetapi soal DIBERIKAN dalam paket peserta)
    - Nilai NaN : Soal TIDAK DIBERIKAN / TIDAK DIUJKAN kepada peserta
    """
    df_respon.columns = df_respon.columns.astype(str).str.strip().str.lower()
    df_kunci.columns = df_kunci.columns.astype(str).str.strip().str.lower()

    # Deteksi kolom ID Peserta
    id_col_respon = None
    for col in ["username", "id_peserta", "id", "nisn", "no_peserta", "nama"]:
        if col in df_respon.columns:
            id_col_respon = col
            break
    if not id_col_respon:
        id_col_respon = df_respon.columns[0]

    # Deteksi kolom Kode Paket jika ada
    kode_paket_col = None
    for col in ["kode_paket", "kd_paket", "paket"]:
        if col in df_respon.columns:
            kode_paket_col = col
            break

    # Deteksi kolom Kode Soal & Kunci Jawaban
    soal_col_kunci = None
    kunci_col_kunci = None
    for col in ["kode_soal", "id_soal", "soal", "no_soal", "kd_soal"]:
        if col in df_kunci.columns:
            soal_col_kunci = col
            break
    for col in ["kunci", "kunci_jawaban", "jawaban", "key"]:
        if col in df_kunci.columns:
            kunci_col_kunci = col
            break

    if not soal_col_kunci:
        soal_col_kunci = df_kunci.columns[0]
    if not kunci_col_kunci:
        kunci_col_kunci = (
            df_kunci.columns[1] if len(df_kunci.columns) > 1 else df_kunci.columns[0]
        )

    # Dictionary Kunci Jawaban
    kunci_dict = dict(
        zip(
            df_kunci[soal_col_kunci].astype(str).str.strip(),
            df_kunci[kunci_col_kunci].astype(str).str.strip().str.upper(),
        )
    )

    # KASUS A: Format List String ('list_soal' & 'respon' dipisah koma)
    if "list_soal" in df_respon.columns and "respon" in df_respon.columns:
        used_items = sorted(list(kunci_dict.keys()))
        item_to_idx = {item: i for i, item in enumerate(used_items)}

        n_rows = len(df_respon)
        n_items = len(used_items)

        # Inisialisasi awal matriks dengan np.nan ( default = TIDAK DIBERIKAN )
        score_matrix = np.full((n_rows, n_items), np.nan, dtype=np.float32)
        jumlah_soal_list = np.zeros(n_rows, dtype=np.uint16)

        raw_list_soal = df_respon["list_soal"].values
        raw_respon = df_respon["respon"].values

        for idx in range(n_rows):
            val_soal = raw_list_soal[idx]
            val_resp = raw_respon[idx]

            str_soal = "" if pd.isna(val_soal) else str(val_soal).strip()
            str_resp = "" if pd.isna(val_resp) else str(val_resp).strip()

            soal_list = [s.strip() for s in str_soal.split(",") if s.strip()]
            respon_list = [r.strip().upper() for r in str_resp.split(",")]

            jumlah_soal_list[idx] = len(soal_list)

            # Hanya isi nilai (0.0 atau 1.0) untuk soal yang DIBERIKAN kepada peserta
            for pos, s_code in enumerate(soal_list):
                if s_code in item_to_idx:
                    resp = respon_list[pos] if pos < len(respon_list) else ""
                    kunci = kunci_dict.get(s_code)
                    
                    if kunci is not None:
                        score_matrix[idx, item_to_idx[s_code]] = (
                            1.0 if (resp != "" and resp == kunci) else 0.0
                        )

        df_matrix = pd.DataFrame(score_matrix, columns=used_items)
        df_matrix.insert(0, id_col_respon, df_respon[id_col_respon].values)
        if kode_paket_col:
            df_matrix.insert(1, "kode_paket", df_respon[kode_paket_col].values)
        df_matrix["Jumlah_Soal"] = jumlah_soal_list

    # KASUS B: Format 'Long'
    elif "kode_soal" in df_respon.columns and "jawaban" in df_respon.columns:
        df_respon["kode_soal_clean"] = df_respon["kode_soal"].astype(str).str.strip()
        df_respon["jawaban_clean"] = (
            df_respon["jawaban"].astype(str).str.strip().str.upper()
        )
        df_respon["kunci_true"] = df_respon["kode_soal_clean"].map(kunci_dict)

        df_respon["skor"] = np.where(
            df_respon["jawaban_clean"] == df_respon["kunci_true"],
            1.0,
            0.0,
        )

        jml_soal_per_user = df_respon.groupby(id_col_respon)[
            "kode_soal_clean"
        ].nunique()

        # Pivot otomatis memberikan NaN untuk kombinasi user-soal yang tidak diujikan
        df_matrix = (
            df_respon.pivot(
                index=id_col_respon, columns="kode_soal_clean", values="skor"
            )
            .reset_index()
        )

        if kode_paket_col:
            paket_map = df_respon.groupby(id_col_respon)[kode_paket_col].first()
            df_matrix.insert(1, "kode_paket", df_matrix[id_col_respon].map(paket_map))

        df_matrix["Jumlah_Soal"] = (
            df_matrix[id_col_respon].map(jml_soal_per_user).fillna(0).astype(int)
        )

    # KASUS C: Format 'Wide'
    else:
        df_matrix = pd.DataFrame()
        df_matrix[id_col_respon] = df_respon[id_col_respon]

        if kode_paket_col:
            df_matrix["kode_paket"] = df_respon[kode_paket_col]

        soal_cols = []
        for col in df_respon.columns:
            if col in [id_col_respon, kode_paket_col]:
                continue

            col_clean = str(col).strip()
            if col_clean in kunci_dict:
                soal_cols.append(col_clean)
                kunci_val = kunci_dict[col_clean]
                resp_val = df_respon[col].astype(str).str.strip().str.upper()
                
                # Membedakan antara null/tidak diujikan (NaN) dan tidak dijawab/salah (0.0)
                df_matrix[col_clean] = np.where(
                    df_respon[col].isna(),
                    np.nan,
                    np.where(resp_val == kunci_val, 1.0, 0.0),
                )

        df_matrix["Jumlah_Soal"] = df_matrix[soal_cols].notna().sum(axis=1)

    df_matrix = df_matrix.loc[:, ~df_matrix.columns.duplicated()].copy()

    # Hitung Skor Mentah & Nilai Konversi (Mengabaikan NaN)
    non_item = [
        id_col_respon,
        "username",
        "kode_paket",
        "skor_mentah",
        "nilai_konversi",
        "jumlah_soal",
    ]
    item_cols = [c for c in df_matrix.columns if c.lower() not in non_item]

    df_matrix["skor_mentah"] = df_matrix[item_cols].sum(axis=1, skipna=True).astype(int)

    df_matrix["Nilai_Konversi"] = np.where(
        df_matrix["Jumlah_Soal"] > 0,
        (df_matrix["skor_mentah"] / df_matrix["Jumlah_Soal"]) * 100.0,
        0.0,
    ).round(2)

    return df_matrix


def calculate_person_fit(df_matrix, df_params, b_col="b"):
    """Menghitung indeks fit peserta (Outfit MSQ)."""
    id_col = df_matrix.columns[0]
    non_item = [
        id_col,
        "username",
        "kode_paket",
        "skor_mentah",
        "skormentah",
        "jumlah_soal",
        "nilai_konversi",
    ]
    item_cols = [c for c in df_matrix.columns if c.lower() not in non_item]

    item_map = dict(zip(df_params[df_params.columns[0]].astype(str), df_params[b_col]))
    b_vec = np.array([item_map.get(str(c), 0.0) for c in item_cols])

    X = df_matrix[item_cols].to_numpy(dtype=np.float32)

    total_scores = np.nansum(X, axis=1)
    n_items_valid = np.sum(~np.isnan(X), axis=1)
    n_items_valid = np.where(n_items_valid == 0, 1, n_items_valid)

    p_scores = np.clip(total_scores / n_items_valid, 0.01, 0.99)
    theta_vec = np.log(p_scores / (1.0 - p_scores))

    theta_mat = theta_vec[:, np.newaxis]
    P = 1.0 / (1.0 + np.exp(-(theta_mat - b_vec)))
    P = np.clip(P, 1e-4, 0.9999)

    W = P * (1.0 - P)
    Z_sq = np.nan_to_num(((X - P) ** 2) / W, nan=0.0)
    
    valid_mask = ~np.isnan(X)
    outfit_msq = np.sum(Z_sq * valid_mask, axis=1) / n_items_valid

    status = np.where(
        (outfit_msq >= 0.5) & (outfit_msq <= 1.5),
        "Pola Normal",
        np.where(outfit_msq > 1.5, "Menebak / Anomali", "Terlalu Menentu"),
    )

    df_res = pd.DataFrame({
        id_col: df_matrix[id_col],
        "Outfit_MSQ": np.round(outfit_msq, 2),
        "Status_Pola_Jawab": status,
    })

    return df_res.loc[:, ~df_res.columns.duplicated()].copy()